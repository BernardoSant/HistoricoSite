const express = require("express");
const db = require("../db/models");
const router = express.Router();

router.post("/", async (req, res) => {
    var data =req.body;

    await db.Notafs.create(data).then((dataNotaf) => {
        return res.json({
            error: false,
            message: "Notaf cadastrada com sucesso!",   
            data: dataNotaf    
        });
    }).catch(() => {
        return res.json({
            error: false,
            message: "Erro: Notaf não cadastrado com sucesso!"
        });
    }); 
})

router.get("/", async (req, res) => {
    await db.Notafs.findAll().then((dataNotaf) => {
        return res.json({
            error: false,
            data: dataNotaf
        });
    }).catch(() => {
        return res.status(500).json({
            error: true,
            message: "Erro: Não foi possível buscar as Notaf!"
        });
    });
});


module.exports = router;